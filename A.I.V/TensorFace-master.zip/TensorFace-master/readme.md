Face recognition using Tensor Flow
======================
**This repo is no longer being maintained. I recommend using my other project [Deep Video Analytics](https://github.com/AKSHAYUBHAT/DeepVideoAnalytics) which implements Face Recognition among other algorithms with an easy to use User Interface using Tensorflow & Facenet.**
